globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/5xsnxmpUQpLHDmolG80BQ/_buildManifest.js",
    "static/5xsnxmpUQpLHDmolG80BQ/_ssgManifest.js",
    "static/5xsnxmpUQpLHDmolG80BQ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0_8y92xg60ach.js",
    "static/chunks/07-hzktxqjvzd.js",
    "static/chunks/3rxl-jt3pdxgx.js",
    "static/chunks/1ly_njwlf0reo.js",
    "static/chunks/turbopack-35t9ha4-6-29g.js"
  ]
};
