1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/0a3_bjsmvkcpo.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/08xnqdavec6ql.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/0a3_bjsmvkcpo.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/08xnqdavec6ql.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Ong Match — หาคนไทป์เดียวกัน"}],["$","meta","1",{"name":"description","content":"ไทป์ไหน? ตรงกันปุ๊บ คุยกันปั๊บ — หาคนไทป์เดียวกัน คุยรู้ใจ ไม่ต้องงง"}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"QrbtVaioKLMXATar41yIj"}
