1:"$Sreact.fragment"
2:I[66845,["/_next/static/chunks/0a3_bjsmvkcpo.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/08xnqdavec6ql.js","/_next/static/chunks/1ubo9_z_jkw8u.js","/_next/static/chunks/382sir2pe1qlp.js","/_next/static/chunks/3twokyy-hl2ab.js","/_next/static/chunks/0lvznj7hucnxm.js","/_next/static/chunks/2bdc38uv798uk.js","/_next/static/chunks/3grgg4-vd3z_r.js","/_next/static/chunks/37irof4ii05_d.js","/_next/static/chunks/3naw92gl4jx01.js"],"default"]
3:I[97367,["/_next/static/chunks/0a3_bjsmvkcpo.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/08xnqdavec6ql.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/3grgg4-vd3z_r.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/37irof4ii05_d.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/3naw92gl4jx01.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"QrbtVaioKLMXATar41yIj"}
5:null
