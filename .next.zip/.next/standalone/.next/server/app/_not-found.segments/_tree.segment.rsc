:HL["/_next/static/chunks/2v-rv291cn1b-.css","style"]
:HL["/_next/static/chunks/2ckudg6h1zhp_.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"5xsnxmpUQpLHDmolG80BQ"}
