1:"$Sreact.fragment"
2:I[25221,["/_next/static/chunks/0a3_bjsmvkcpo.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/08xnqdavec6ql.js","/_next/static/chunks/1ubo9_z_jkw8u.js","/_next/static/chunks/382sir2pe1qlp.js","/_next/static/chunks/3twokyy-hl2ab.js","/_next/static/chunks/0lvznj7hucnxm.js","/_next/static/chunks/2bdc38uv798uk.js","/_next/static/chunks/32hqp5huctr5z.js","/_next/static/chunks/3yz1idksb-uci.js","/_next/static/chunks/35cibrv20xifv.js"],"default"]
3:I[97367,["/_next/static/chunks/0a3_bjsmvkcpo.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/08xnqdavec6ql.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/32hqp5huctr5z.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/3yz1idksb-uci.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/35cibrv20xifv.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"QrbtVaioKLMXATar41yIj"}
5:null
