module.exports=[38251,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_chat_page_actions_062sia0.js.map