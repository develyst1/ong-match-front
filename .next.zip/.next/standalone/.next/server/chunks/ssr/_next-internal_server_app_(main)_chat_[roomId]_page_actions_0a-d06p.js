module.exports=[33434,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_chat_%5BroomId%5D_page_actions_0a-d06p.js.map