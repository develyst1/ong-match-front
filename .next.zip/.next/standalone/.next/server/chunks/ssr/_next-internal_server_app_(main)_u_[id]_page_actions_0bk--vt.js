module.exports=[50932,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_u_%5Bid%5D_page_actions_0bk--vt.js.map