module.exports=[8314,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_tribes_page_actions_1yvbyaq.js.map